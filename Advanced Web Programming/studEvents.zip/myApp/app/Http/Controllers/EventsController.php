<?php

namespace App\Http\Controllers;

use App\Event;
use App\User;
use Illuminate\Http\Request;
use Intervention\Image\Facades\Image;

class EventsController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {

        $events = Event::latest()->paginate(6);

        return view('events.index', compact('events'));
    }

    public function order()
    {
        $events = Event::orderBy('date', 'ASC')->paginate(6);

        return view('events.index', compact('events'));
    }

    public function search()
    {
        $data = request()->validate([
            'search' => 'required'
        ]);

        $events = Event::where('location', $data['search'])->latest()->paginate(6);

        return view('events.index', compact('events'));
    }

    public function create()
    {

        return view('events.create');
    }

    public function store()
    {
        $data = request()->validate([
            'title' => 'required',
            'location' => 'required',
            'date' => 'required',
            'description' => 'required',
            'image' => ['required', 'image'],
        ]);

        $imagePath = request('image')->store('uploads', 'public');

        $image = Image::make(public_path("/storage/{$imagePath}"))->fit(500, 500);
        $image->save();

        auth()->user()->events()->create([
            'title' => $data['title'],
            'location' => $data['location'],
            'date' => $data['date'],
            'description' => $data['description'],
            'image' => $imagePath,
        ]);

        return redirect('/profile/' . auth()->user()->id);

    }

    public function show(\App\Event $event)
    {

        $userId = auth()->user()->id;

        $check = $event->people()->pluck('users.id');
        if ($check->contains($userId)){
            $goes = true;
        } else {
            $goes = false;
        }

        return view('events.show', compact('event', 'userId', 'goes'));
    }

    public function view(Event $event)
    {
        $usersId = $event->people()->pluck('users.id');
        $users = User::whereIn('id', $usersId)->get();

        return view('events.view', compact('users'));
    }



    public function delete(\App\Event $event)
    {
        $user = auth()->user()->id;
        $event -> delete();
        return redirect('/profile/'.$user);
    }
}
