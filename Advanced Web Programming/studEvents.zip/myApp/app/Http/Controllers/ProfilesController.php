<?php

namespace App\Http\Controllers;

use App\User;
use App\Event;
use Illuminate\Http\Request;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Facades\Mail;
use App\Mail\EventUpdated;


class ProfilesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
  public function index(User $user)
  {
      $follows = (auth()->user()) ? auth()->user()->following->contains($user->id) : false;
      $evnts = Event::all();
      $goEvents = [];
      foreach ($evnts as $evnt){
          $goingEvents = $evnt->people()->pluck('users.id')->contains($user->id);
          if ($goingEvents) {
              array_push($goEvents, $evnt);
          }
      }

      return view('profiles.index', compact('user', 'goEvents', 'follows'));
  }

  public function edit(User $user)
  {
      $this->authorize('update', $user->profile);
      return view('profiles.edit', compact('user'));
  }

  public function update(User $user)
  {

      $this->authorize('update', $user->profile);

      $data = request()->validate([
          'university' => 'required',
          'bio' => 'required',
          'image' => '',
      ]);

      if (request('image')){
          $imagePath = request('image')->store('profile', 'public');

          $image = Image::make(public_path("/storage/{$imagePath}"))->fit(400,450);
          $image->save();
          $imageArray = ['image' => $imagePath];
      }


      auth()->user()->profile->update(array_merge(
          $data,
          $imageArray ?? []
      ));

      Mail::to ($user->email) -> send(new EventUpdated($user));

      return redirect('profile/'. $user->id);


  }
}
