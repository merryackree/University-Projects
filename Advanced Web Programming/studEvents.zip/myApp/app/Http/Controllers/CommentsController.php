<?php

namespace App\Http\Controllers;

use App\Event;
use App\Comment;
use App\User;
use Illuminate\Http\Request;

class CommentsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function show(Event $event){
        $user = auth()->user();
        $userId = auth()->user()->id;
        $comments = $event->comments;
        $check = $event->people()->pluck('users.id');
        if ($check->contains($userId)){
            $goes = true;
        } else {
            $goes = false;
        }

        return view('events.comments', compact('event', 'user', 'goes', 'comments'));
    }

    public function store(Event $event){
        $url = 'comments/'.$event->id;
        $data = request() -> validate([
            'comment' => 'required'
        ]);
        $event->comments()->create([
            'comment' => $data['comment'],
            'user_id' => auth()->user()->id
        ]);

         return redirect($url);
    }

    public function update(Comment $comment){
        $data = request() -> validate([
            'comment' => 'required'
        ]);
            $comment->update([
                'comment' => $data['comment'],
                'user_id' => auth()->user()->id,
                'event_id' => $comment->event->id
            ]);
            return redirect('comments/'. $comment->event->id);

    }

    public function edit(Comment $comment){

        if ($comment->user->id == auth()->user()->id){
            $event = $comment->event;
            $user = auth()->user();
            return view('comments.edit', compact('user', 'comment', 'event'));
        } else {
            return redirect('comments/error');
        }

    }

    public function delete(Comment $comment)
    {
        $url = 'comments/'.$comment->event->id;
        $comment -> delete();
        return redirect($url);
    }
}
