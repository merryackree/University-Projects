<?php

namespace App\Http\Controllers;
use \App\User;
use \App\Event;
use Illuminate\Http\Request;

class GoesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function store(\App\Event $event){

        $user = auth()->user();

        return $event->people()->toggle($user);

    }
}
