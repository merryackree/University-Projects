<template>
    <div>
        <button class="btn btn-primary" @click="goToEvent" v-text="buttonText"></button>


    </div>
</template>

<script>
    export default {
        props: ['eventId', 'goes'],
        mounted() {
            console.log('Component mounted.')
        },
        data: function () {
            return {
                status: this.goes,
            }
        },
        methods: {
            goToEvent() {
                axios.post('/go/' + this.eventId)
                    .then(response => {
                        this.status = !this.status;
                        console.log(response.data);
                    })

            }
        },
        computed: {
            buttonText() {
                return (this.status) ? 'Going' : 'Not Going';
            }
        }
    }
</script>
