@extends('layouts.app')
@section('page-heading')
    <a class="dropdown-item" href="/profile/{{auth()->user()->id}}"
    >
        My Profile
    </a>
@endsection
@section('content')
<div class="container" style="width: 600">
    <h2 class="text-center">Events Browse</h2>
    <div class="p-5" style="margin-top: 5px">
        <div class="d-flex justify-content-center">
        <form action="/search/" method="get">
            <label for="city">Search for events in your city</label>
            <input type="text" name="search" id="city" placeholder="Enter your city..." class="form-text">
            <button type="submit" class="btn btn-primary p-2 mt-3">Search</button>
        </form>
        </div>
        <a href="/order/">Order by Date &#8593</a>
        <a href="/" class="float-right">Latest update &#8595</a>

    <div class="row">
        @foreach($events as $event)
            <div class="col-sm-4 justify-content-center p-3">
                <figure class="figure">
                    <a href="/event/{{$event->id}}" style="color: black">
                    <p>{{$event->title}} | {{$event->location}} | {{$event->date}}</p>
                    <img src="/storage/{{$event->image}}" class="figure-img img-fluid rounded" alt="Event thumbnail">
                    <figcaption class="figure-caption text-right">{{$event->people()->count()}} people are going</figcaption></a>
                </figure>

            </div>

        @endforeach

    </div>
        <div class="row">
            <div class="col-12 d-flex justify-content-center">
                {{$events->links()}}
            </div>
        </div>
    </div>

</div>
@endsection


