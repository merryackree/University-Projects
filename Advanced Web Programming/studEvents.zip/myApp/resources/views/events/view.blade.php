@extends('layouts.app')

@section('page-heading')
    <a class="dropdown-item" href="/profile/{{auth()->user()->id}}"
    >
        My Profile
    </a>
@endsection

@section('content')
<div class="container" style="width: 600">
    <div class="border p-5" style="margin-top: 15%; background-color: white">

            <h3>People going:</h3>
        <div class="row">
            @foreach($users as $user)
            <div class="col-6 d-flex pt-2">
                <a href="/profile/{{$user->id}}">
                 <img src="{{$user->profile->profileImage()}}" class="rounded-circle" style="width: 50px">
                    {{$user->username}}
                </a>
                </div>
                @endforeach

        </div>


    </div>
</div>
@endsection
