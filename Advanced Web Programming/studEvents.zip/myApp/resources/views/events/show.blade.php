@extends('layouts.app')

@section('page-heading')
    <a class="dropdown-item" href="/profile/{{auth()->user()->id}}">
        My Profile
    </a>
@endsection

@section('content')
<div class="container" style="width: 600">
    <div class="border p-5" style="margin-top: 15%; background-color: white">
        <div class="row justify-content-center mb-3"><h1>{{$event->title}}</h1>
            <going-button event-id= "{{$event->id}}" goes="{{$goes}}" class="pl-3 pt-1"></going-button>
        </div>
    <div class="row">
            <div class="col-sm-6 justify-content-center">
                <img src="/storage/{{$event->image}}" class="w-75 pr-5 ml-5" style="border-right: 2px solid gray">
                <a href="/view/{{$event->id}}" style="color: black"><h4 class="pt-2 ml-5">{{$event->people()->count()}} people are going</h4></a>
            </div>
            <div class="col-sm-6">
                <div class="d-flex align-items-baseline border-bottom">
                    <img src="{{$event->user->profile->profileImage()}}" class="w-25">
                    <a href="/profile/{{$event->user->id}}"><h3 class="pl-2">{{$event->user->username}}</h3></a>

                </div>

                <div class="pt-4">
                <h3>Location: {{$event->location}}</h3>
                <h3>Date: {{$event->date}}</h3>
                <p class="font-weight-bold">Description: {{$event->description}}</p>
                  @if($userId == $event->user_id)
                        <a href="/event/{{$event->id}}/delete" style="text-decoration: none"><button class="button is-danger is-outlined">Delete Event</button></a>
                  @endif
                    <a href="/comments/{{$event->id}}" style="text-decoration: none" class="pl-2"><button class="button is-link is-outlined">View Comments</button></a>
                </div>

            </div>



    </div>
    </div>
</div>
@endsection
