@extends('layouts.app')

@section('page-heading')
    <a class="dropdown-item" href="/profile/{{auth()->user()->id}}">
        My Profile
    </a>
@endsection

@section('content')
<div class="container" style="width: 600">
    <div class="border p-5" style="margin-top: 15%; background-color: white">
    <div class="row">
            <div class="col-sm-6 justify-content-center">
                <div class="d-flex pl-5 pb-4">
                    <h1>{{$event->title}}</h1>
                    <going-button event-id= "{{$event->id}}" goes="{{$goes}}" class="pl-3 pt-1"></going-button>
                </div>
                <img src="/storage/{{$event->image}}" class="w-75 pr-5 ml-5" style="border-right: 2px solid gray">
                <div class="row">
                    <div class="col-sm-2"></div>
                    <div class="col-sm-6 text-center pt-2 pb-2">
                        <p>{{$event->description}}</p>
                    </div>
                    <div class="col-sm-4"></div>
                </div>




            </div>
            <div class="col-sm-6">
                <div class="d-flex align-items-baseline border-bottom">
                    <img src="{{$event->user->profile->profileImage()}}" class="w-25">
                    <h5 class="pl-2">Organized by</h5>
                    <a href="/profile/{{$event->user->id}}"><h3 class="pl-2">{{$event->user->username}} </h3></a>

                </div>

                <div class="pt-4">
                    <p>Comments to event ({{$comments->count()}})</p>
                    @foreach($comments as $comment)
                        <div>
                            <div class="d-flex align-items-center">
                            <img src="{{$comment->user->profile->profileImage()}}" class="w-25 rounded-circle" style="max-width: 40px">
                            <a href="/profile/{{$comment->user->id}}"><span class="font-weight-bold text-dark pr-1 pl-2">{{$comment->user->username}} </span></a>
                            <span class="">&nbsp;{{$comment->comment}}</span>
                            @if(auth()->user()->id == $comment->user->id)
                                <a href="edit/{{$comment->id}}" class="pl-2"><span title="Edit"><i class="fas fa-edit"></i></span></a>
                                <a href="delete/{{$comment->id}}"><span title="Remove"><i class="fas fa-trash"></i></span></a>
                            @else
                                <a href="like/{{$comment->id}}" class="like-button pl-2"><i class="far fa-heart"></i></a>
                            @endif
                            </div>
                        <hr>

                        </div>

                    @endforeach
                    <form action="{{$event->id}}/store" method="post">
                        @csrf
                        <div class="d-flex align-items-baseline">
                            <img src="{{auth()->user()->profile->profileImage()}}" class="w-25 mr-2" style="max-width: 40px">
                            <input type="text" placeholder="Leave a comment..." name="comment" class="form-control">
                            <button class="btn btn-primary ml-3" type="submit"><span title="Add Comment"><i class="fas fa-paper-plane"></i></span></button>
                        </div>

                    </form>

            </div>



    </div>
    </div>
</div>
@endsection
