@extends('layouts.app')

@section('page-heading')
    <a class="dropdown-item" href="/profile/{{auth()->user()->id}}">
        My Profile
    </a>
@endsection

@section('content')
    <div class="container">
        <form action="/comments/{{$comment->id}}" enctype="multipart/form-data" method="post">
            @csrf
            @method('PATCH')
            <div class="row">
                <div class="col-sm-6 offset-3">
                    <div class="row">
                        <h1>Edit Comment</h1>
                    </div>
                    <div class="form-group row">
                        <label for="comment" class="col-md-4 col-form-label">Comment</label>

                        <input id="comment" type="text" class="form-control @error('comment') is-invalid @enderror" name="comment" value="{{ old('comment') ?? $comment->comment }}"  autocomplete="comment">

                        @error('comment')
                        <span class="invalid-feedback" role="alert">
                          <strong>{{ $message }}</strong>
                    </span>
                        @enderror

                    </div>

                    <div class="row pt-4">
                        <button type="submit" class="btn btn-primary">Save Comment</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
@endsection
