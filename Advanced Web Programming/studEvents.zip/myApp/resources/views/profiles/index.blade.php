@extends('layouts.app')

@section('page-heading')
    <a class="dropdown-item" href="/profile/{{auth()->user()->id}}"
    >
        My Profile
    </a>
    @endsection

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <div class="p-photo p-block text-center">

                    @can('update', $user->profile)
                        <a href="/profile/{{$user->id}}/edit" class="d-block pb-2">Edit Profile</a>
                    @endcan
                    <img src="{{$user->profile->profileImage()}}" style="height: 225px">
                    <h4 class="pt-2">{{$user->name}}</h4>
                </div>
            </div>

            <div class="col-sm-5 pt-3">
                @if(auth()->user()->id == $user->id)
                    <div class="p-username d-flex align-items-baseline">{{ $user->username }}</div>
                    @else
                    <div class="p-username d-flex align-items-baseline">{{ $user->username }}<follow-button user-id="{{$user->id}}" follows="{{$follows}}" class="pl-3"></follow-button></div>
                    @endif

                <div class="d-flex pt-2">
                    <div class="pr-5"><strong>{{$user->events->count()}}</strong> events</div>
                    <div class="pr-5"><strong>{{$user->profile->followers->count()}}</strong> followers</div>
                    <div class="pr-5"><strong>{{$user->following->count()}}</strong> following</div>
                </div>
                <p class="p-uni pt-3">{{$user->profile->university}}</p>

                    <p class="p-bio">Biography:</p>
                    <p class="p-desc">{{$user->profile->bio}}</p>

                @can('update', $user->profile)
                    <div class="mt-5 align-bottom"><a href="/event/create" class="btn btn-primary">Create new event</a></div>

                @endcan
            </div>

            <div class="col-sm-3 pt-3">
                <h4>Going to:</h4>
                @foreach($goEvents as $goEvent)
                    <figure class="figure">
                        <a href="/event/{{$goEvent->id}}" style="color: black">
                            <figcaption class="figure-caption text-right">{{$goEvent->title}} | {{$goEvent->people()->count()}} people are going</figcaption>
                            <img src="/storage/{{$goEvent->image}}" class="figure-img img-fluid rounded" alt="Event thumbnail"></a>
                @endforeach
            </div>
        </div>
        <div>
            <h3 class="text-center pb-2">{{$user->username}}'s Events</h3>
            <hr>
            <div class="row">

                @foreach($user->events as $event)
                    <div class="col-sm-4">
                        <a href="/event/{{$event->id}}">
                            <figcaption class="figure-caption text-center">{{$event->title}} | {{$event->date}}</figcaption>
                            <img src="/storage/{{ $event->image }}" class="w-100">
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
@endsection
