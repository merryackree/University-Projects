@component('mail::message')
# Hello {{ $profile -> user->username}},

Your profile has been recently updated.


Thanks,<br>
{{ config('app.name') }}
@endcomponent
