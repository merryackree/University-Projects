@component('mail::message')
# Hello from Victor Meriacri,

Welcome to studEvents application.



Thanks,<br>
{{ config('app.name') }}
@endcomponent
