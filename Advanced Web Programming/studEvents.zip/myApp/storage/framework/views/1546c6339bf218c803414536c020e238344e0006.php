<?php $__env->startSection('page-heading'); ?>
    <a class="dropdown-item" href="/profile/<?php echo e(auth()->user()->id); ?>"
    >
        My Profile
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container" style="width: 600">
    <div class="border p-5" style="margin-top: 15%; background-color: white">

            <h3>People going:</h3>
        <div class="row">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-6 d-flex pt-2">
                <a href="/profile/<?php echo e($user->id); ?>">
                 <img src="<?php echo e($user->profile->profileImage()); ?>" class="rounded-circle" style="width: 50px">
                    <?php echo e($user->username); ?>

                </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Windows\System32\myApp\resources\views/events/view.blade.php ENDPATH**/ ?>