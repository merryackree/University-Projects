<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
      <div class="col-3 p-5">
          <img src="https://previews.123rf.com/images/vladgrin/vladgrin1302/vladgrin130200034/18021565-the-concept-of-learning-vector-background-of-the-many-icons-on-the-topic-of-education.jpg" style="height: 200px" class="border">
      </div>
      <div class="col-9 p-5">
        <div><h1><?php echo e($user->username); ?></h1></div>
        <div class="pt-1">Victor Meriacri</div>
        <div class="pt-2 font-weight-bold"><i><?php echo e($user->profile->university); ?></i></div>
        <div class="mt-2">
          <div><strong>Biography:</strong></div>
          <div><?php echo e($user->profile->bio); ?></div>
            <div><a href="#">Create new event</a></div>
        </div>

      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Windows\System32\myApp\resources\views/index.blade.php ENDPATH**/ ?>
