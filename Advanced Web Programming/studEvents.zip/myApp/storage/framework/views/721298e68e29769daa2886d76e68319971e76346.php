<?php $__env->startSection('page-heading'); ?>
    <a class="dropdown-item" href="/profile/<?php echo e(auth()->user()->id); ?>"
    >
        My Profile
    </a>
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <div class="p-photo p-block text-center">

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user->profile)): ?>
                        <a href="/profile/<?php echo e($user->id); ?>/edit" class="d-block pb-2">Edit Profile</a>
                    <?php endif; ?>
                    <img src="<?php echo e($user->profile->profileImage()); ?>" style="height: 225px">
                    <h4 class="pt-2"><?php echo e($user->name); ?></h4>
                </div>
            </div>

            <div class="col-sm-5 pt-3">
                <?php if(auth()->user()->id == $user->id): ?>
                    <div class="p-username d-flex align-items-baseline"><?php echo e($user->username); ?></div>
                    <?php else: ?>
                    <div class="p-username d-flex align-items-baseline"><?php echo e($user->username); ?><follow-button user-id="<?php echo e($user->id); ?>" follows="<?php echo e($follows); ?>" class="pl-3"></follow-button></div>
                    <?php endif; ?>

                <div class="d-flex pt-2">
                    <div class="pr-5"><strong><?php echo e($user->events->count()); ?></strong> events</div>
                    <div class="pr-5"><strong><?php echo e($user->profile->followers->count()); ?></strong> followers</div>
                    <div class="pr-5"><strong><?php echo e($user->following->count()); ?></strong> following</div>
                </div>
                <p class="p-uni pt-3"><?php echo e($user->profile->university); ?></p>

                    <p class="p-bio">Biography:</p>
                    <p class="p-desc"><?php echo e($user->profile->bio); ?></p>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user->profile)): ?>
                    <div class="mt-5 align-bottom"><a href="/event/create" class="btn btn-primary">Create new event</a></div>

                <?php endif; ?>
            </div>

            <div class="col-sm-3 pt-3">
                <h4>Going to:</h4>
                <?php $__currentLoopData = $goEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goEvent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <figure class="figure">
                        <a href="/event/<?php echo e($goEvent->id); ?>" style="color: black">
                            <figcaption class="figure-caption text-right"><?php echo e($goEvent->title); ?> | <?php echo e($goEvent->people()->count()); ?> people are going</figcaption>
                            <img src="/storage/<?php echo e($goEvent->image); ?>" class="figure-img img-fluid rounded" alt="Event thumbnail"></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div>
            <h3 class="text-center pb-2"><?php echo e($user->username); ?>'s Events</h3>
            <hr>
            <div class="row">

                <?php $__currentLoopData = $user->events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-4">
                        <a href="/event/<?php echo e($event->id); ?>">
                            <figcaption class="figure-caption text-center"><?php echo e($event->title); ?> | <?php echo e($event->date); ?></figcaption>
                            <img src="/storage/<?php echo e($event->image); ?>" class="w-100">
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Windows\System32\myApp\resources\views/profiles/index.blade.php ENDPATH**/ ?>