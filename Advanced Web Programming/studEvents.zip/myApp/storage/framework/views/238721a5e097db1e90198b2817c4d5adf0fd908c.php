

<a href="/auth/github/callback">
    Sing in with GitHub
</a>
<?php /**PATH C:\Windows\System32\myApp\resources\views/auth/github-login.blade.php ENDPATH**/ ?>