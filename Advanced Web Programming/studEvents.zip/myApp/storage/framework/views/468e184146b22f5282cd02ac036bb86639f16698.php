<?php $__env->startComponent('mail::message'); ?>
# Hello from Victor Meriacri,

Welcome to studEvents application.



Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Windows\System32\myApp\resources\views/emails/welcome.blade.php ENDPATH**/ ?>