<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Windows\System32\myApp\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>