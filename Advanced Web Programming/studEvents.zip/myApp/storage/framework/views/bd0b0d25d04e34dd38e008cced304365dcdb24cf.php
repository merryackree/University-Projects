<?php $__env->startComponent('mail::message'); ?>
# Hello <?php echo e($profile -> user->username); ?>,

Your profile has been recently updated.


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Windows\System32\myApp\resources\views/emails/event/updated.blade.php ENDPATH**/ ?>