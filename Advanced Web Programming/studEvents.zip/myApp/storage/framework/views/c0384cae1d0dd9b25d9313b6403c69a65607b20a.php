<?php $__env->startSection('page-heading'); ?>
    <a class="dropdown-item" href="/profile/<?php echo e(auth()->user()->id); ?>">
        My Profile
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container" style="width: 600">
    <div class="border p-5" style="margin-top: 15%; background-color: white">
        <div class="row justify-content-center mb-3"><h1><?php echo e($event->title); ?></h1>
            <going-button event-id= "<?php echo e($event->id); ?>" goes="<?php echo e($goes); ?>" class="pl-3 pt-1"></going-button>
        </div>
    <div class="row">
            <div class="col-sm-6 justify-content-center">
                <img src="/storage/<?php echo e($event->image); ?>" class="w-75 pr-5 ml-5" style="border-right: 2px solid gray">
                <a href="/view/<?php echo e($event->id); ?>" style="color: black"><h4 class="pt-2 ml-5"><?php echo e($event->people()->count()); ?> people are going</h4></a>
            </div>
            <div class="col-sm-6">
                <div class="d-flex align-items-baseline border-bottom">
                    <img src="<?php echo e($event->user->profile->profileImage()); ?>" class="w-25">
                    <a href="/profile/<?php echo e($event->user->id); ?>"><h3 class="pl-2"><?php echo e($event->user->username); ?></h3></a>

                </div>

                <div class="pt-4">
                <h3>Location: <?php echo e($event->location); ?></h3>
                <h3>Date: <?php echo e($event->date); ?></h3>
                <p class="font-weight-bold">Description: <?php echo e($event->description); ?></p>
                  <?php if($userId == $event->user_id): ?>
                        <a href="/event/<?php echo e($event->id); ?>/delete" style="text-decoration: none"><button class="button is-danger is-outlined">Delete Event</button></a>
                  <?php endif; ?>
                    <a href="/comments/<?php echo e($event->id); ?>" style="text-decoration: none" class="pl-2"><button class="button is-link is-outlined">View Comments</button></a>
                </div>

            </div>



    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Windows\System32\myApp\resources\views/events/show.blade.php ENDPATH**/ ?>