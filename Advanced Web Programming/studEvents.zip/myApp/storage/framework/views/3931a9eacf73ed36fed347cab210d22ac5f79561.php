<?php $__env->startSection('page-heading'); ?>
    <a class="dropdown-item" href="/profile/<?php echo e(auth()->user()->id); ?>">
        My Profile
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container" style="width: 600">
    <div class="border p-5" style="margin-top: 15%; background-color: white">
    <div class="row">
            <div class="col-sm-6 justify-content-center">
                <div class="d-flex pl-5 pb-4">
                    <h1><?php echo e($event->title); ?></h1>
                    <going-button event-id= "<?php echo e($event->id); ?>" goes="<?php echo e($goes); ?>" class="pl-3 pt-1"></going-button>
                </div>
                <img src="/storage/<?php echo e($event->image); ?>" class="w-75 pr-5 ml-5" style="border-right: 2px solid gray">
                <div class="row">
                    <div class="col-sm-2"></div>
                    <div class="col-sm-6 text-center pt-2 pb-2">
                        <p><?php echo e($event->description); ?></p>
                    </div>
                    <div class="col-sm-4"></div>
                </div>




            </div>
            <div class="col-sm-6">
                <div class="d-flex align-items-baseline border-bottom">
                    <img src="<?php echo e($event->user->profile->profileImage()); ?>" class="w-25">
                    <h5 class="pl-2">Organized by</h5>
                    <a href="/profile/<?php echo e($event->user->id); ?>"><h3 class="pl-2"><?php echo e($event->user->username); ?> </h3></a>

                </div>

                <div class="pt-4">
                    <p>Comments to event (<?php echo e($comments->count()); ?>)</p>
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>
                            <div class="d-flex align-items-center">
                            <img src="<?php echo e($comment->user->profile->profileImage()); ?>" class="w-25 rounded-circle" style="max-width: 40px">
                            <a href="/profile/<?php echo e($comment->user->id); ?>"><span class="font-weight-bold text-dark pr-1 pl-2"><?php echo e($comment->user->username); ?> </span></a>
                            <span class="">&nbsp;<?php echo e($comment->comment); ?></span>
                            <?php if(auth()->user()->id == $comment->user->id): ?>
                                <a href="edit/<?php echo e($comment->id); ?>" class="pl-2"><span title="Edit"><i class="fas fa-edit"></i></span></a>
                                <a href="delete/<?php echo e($comment->id); ?>"><span title="Remove"><i class="fas fa-trash"></i></span></a>
                            <?php else: ?>
                                <a href="like/<?php echo e($comment->id); ?>" class="like-button pl-2"><i class="far fa-heart"></i></a>
                            <?php endif; ?>
                            </div>
                        <hr>

                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <form action="<?php echo e($event->id); ?>/store" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="d-flex align-items-baseline">
                            <img src="<?php echo e(auth()->user()->profile->profileImage()); ?>" class="w-25 mr-2" style="max-width: 40px">
                            <input type="text" placeholder="Leave a comment..." name="comment" class="form-control">
                            <button class="btn btn-primary ml-3" type="submit"><span title="Add Comment"><i class="fas fa-paper-plane"></i></span></button>
                        </div>

                    </form>

            </div>



    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Windows\System32\myApp\resources\views/events/comments.blade.php ENDPATH**/ ?>