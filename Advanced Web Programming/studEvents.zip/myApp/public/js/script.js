

document.querySelectorAll('.like-button').forEach(item => {
    item.addEventListener('click', event => {
        event.preventDefault();
        if (item.innerHTML.indexOf('data-prefix="far"')>-1){
            item.innerHTML = '<span title="Dislike comment"><i class="fas fa-heart"></i></span>';
        } else if (item.innerHTML.indexOf('data-prefix="fas"')>-1){
            item.innerHTML = '<span title="Like comment"><i class="far fa-heart"></i></span>';
        } else {
            console.log('error')
        }
    })
});






