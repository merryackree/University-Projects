<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Auth::routes();

Route::post('go/{event}', 'GoesController@store');
Route::post('follow/{user}', 'FollowsController@store');


Route::get('/', 'EventsController@index');
Route::get('/event/create', 'EventsController@create');
Route::post('/event', 'EventsController@store');
Route::get('/event/{event}/delete', 'EventsController@delete');
Route::get('/event/{event}', 'EventsController@show');
Route::get('/view/{event}', 'EventsController@view');
Route::get('/order/', 'EventsController@order');
Route::get('/search/', 'EventsController@search');
Route::get('/comments/delete/{comment}', 'CommentsController@delete');
Route::post('/comments/{event}/store', 'CommentsController@store');
Route::get('/comments/{event}', 'CommentsController@show');
Route::get('/comments/edit/{comment}', 'CommentsController@edit');

Route::get('/sign-in/github', 'Auth\LoginController@github');
Route::get('/sign-in/github/redirect', 'Auth\LoginController@githubRedirect');



Route::patch('/comments/{comment}', 'CommentsController@update');
Route::get('/profile/{user}', 'ProfilesController@index')->name('profile.show');
Route::get('/profile/{user}/edit', 'ProfilesController@edit')->name('profile.edit');
Route::patch('/profile/{user}', 'ProfilesController@update')->name('profile.update');



